commands
conda create -n wineq python=3.7 -y
conda activate wineq

create requirements.txt
pip install -r requirements.txt
